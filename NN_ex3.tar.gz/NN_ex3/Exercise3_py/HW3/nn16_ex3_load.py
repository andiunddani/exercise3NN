import pickle as pckl  # to load dataset
import pylab as pl     # for graphics
import numpy as np
from numpy import *

pl.close('all')   # closes all previous figures

# # Load dataset
# file_in = open('vehicle.pkl','rb')
# vehicle_data = pckl.load(file_in)
# file_in.close()

with open('vehicle.pkl','rb') as f:
    u = pckl._Unpickler(f)
    u.encoding = 'latin1'
    vehicle_data = u.load()
    # print(p)

X = vehicle_data[0]   # input vectors X[i,:] is i-th example
C = vehicle_data[1]   # classes C[i] is class of i-th example

# get data where class is 2
if_class_2 = C == 2

# get data where class is 3
if_class_3 = C == 3

