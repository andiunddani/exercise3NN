import batch_gradient as bg
import numpy as np

