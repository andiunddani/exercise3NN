class batch_gradient():

    def __init__(self):
        import numpy as np

        self.N = 0
        self.N_i = 0
        self.mu = np.zeros(0)
        self.x_n = np.zeros(0)
        self.target = np.zeros(0)

    # sigmund function for batch gradient descent
    def sigm(self, z):
        import numpy as np

        sigm_func = 1/(1 + np.exp(-z))

        return sigm_func

    # input for sigmund function
    def input_sigm(self, N, N_i, x_n, mu):
        import numpy as np

        S_i = 1/N_i*np.sum((x_n - mu) * np.flipud(x_n - mu))

        covarianz = N_i/N * S_i #+ (N-N_i)/N * S_i

        omega_k = covarianz * mu
        omega_k0 = -0.5*np.flipud(mu) + np.log(N_i/N)

        a_k = np.flipud(omega_k)*x_n + omega_k0

        return a_k

    def compute_cost(self):
        import numpy as np

        z = self.input_sigm(N=self.N, N_i= self.N_i, x_n=self.x_n, mu=self.mu)
        y_n = self.sigm(z=z)
        gradient = np.sum(y_n - self.target)*self.x_n

        return gradient

    # def find_omega(self):


